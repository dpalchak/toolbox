#include <X11/Xlib.h>
#include <X11/extensions/Xdbe.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <signal.h>
#include <math.h>
#include <time.h>
#include <sys/errno.h>
#include <stropts.h>
#include <sys/time.h>
#include <sys/ioctl.h>

#include <errno.h>
#include <string.h>

#define DEBUG 0

#define SAMPLE_INTERVAL 1.00



#define	MAX_DATA_SAMPLES 4000000
#define NUM_FIELDS 25
#define NUM_FILES 25


#define NumWindows 1
#define	Main_Window 0

#define	NUM_COLORS	8

#define INITIAL_XLL             10
#define INITIAL_YLL             800
#define INITIAL_XUR             1000
#define INITIAL_YUR             50

#define LABEL_WIDTH		250
#define LABEL_STRIDE		30

#define MAX_PIX_DIST 20

char	text[128];
char	name[132], input_file_name[NUM_FILES][132];
char	time_string[132];
int	quit, done, debug_level, passes, file_EOF;
FILE	*input_file;


Window          The_Window[NumWindows];
GC              The_gc[NumWindows], mygc;
XSizeHints      The_hint[NumWindows], myhint;
XWMHints        The_wmhint[NumWindows], mywmhint;
unsigned long   The_foreground[NumWindows], The_background[NumWindows], myforeground, mybackground;
Colormap        The_cmap[NumWindows];
XWindowAttributes The_attribs[NumWindows];

XColor          channel_color[NUM_COLORS], Background, Black, White;
XColor          R_Background, R_Black, R_White;

XEvent  the_Event;      /* holds the event record       */
Display *mydisplay;
XEvent  myevent;
int     myscreen;
Font	font;
int	color_index;

XID	 Double_Buffer[NumWindows];
XdbeSwapInfo swap_info;
int	use_dbe;


#define		DOUBLETIME 400
int             mouse_x, mouse_y, mouse_down_x, mouse_down_y, mouse_up_x, mouse_up_y, mouse_is_down;
int		old_mouse_index, mouse_index, mouse_data_index;
unsigned int    buttons;
int		button_type;
char		key;
int		ctrl_pressed, alt_pressed, shift_pressed, Double_Clicked;
Time		LastMouseDown, MouseDTime;

int		window_start, window_stop;
int		m_x_delta, xdelta, old_xdelta, m_y_delta, old_m_y_delta;
int		cursor_position, channel_number, scroll_mode, pause_mode;
int		current_yur, current_yll, current_xur, current_xll;

int	status;


long	data[NUM_FIELDS][MAX_DATA_SAMPLES];
int	prev[MAX_DATA_SAMPLES];
int	next[MAX_DATA_SAMPLES];
int	head[NUM_FILES], current_file, num_files;

int	actual_number_of_samples;
double	yscale[NUM_FIELDS];
long	min_sample[NUM_FIELDS], max_sample[NUM_FIELDS];
int	y_offset[NUM_FIELDS], y_delta[NUM_FIELDS];
int	show_field[NUM_FIELDS];
int	delta[MAX_DATA_SAMPLES];
int	show_grid;

char	field_names[NUM_FIELDS][128];

int	timer_interval;
struct  sigaction alarm_action;
struct  itimerval timer_struct;
struct  timeval usec_time;
struct  timezone usec_tz;
double	the_time, last_time;
double	timestamps[MAX_DATA_SAMPLES];

int	repaint_request;

int	num_fields;
char	wfn, cfn, mf;

double	sample_time_avg, sample_interval;
int	use_stdin, use_file, no_timestamp_mode;


int	marker_x, marker_y, omarker_x, omarker_y, marker_index, omarker_index;
double	marker_data, omarker_data, marker_value_delta, marker_time, omarker_time, marker_time_delta;

int	spl_val;

char time_res[32];




main(argc, argv) int argc; char *argv[]; {
int	i, j, f, fn, num_samples, sret, master_idx;
long	raw_value;
FILE	*data_file;
struct stat     stat_info;

        init();

	use_file = 0;
	use_stdin = 0;
	no_timestamp_mode = 0;
	fn = 0;
	sample_interval = SAMPLE_INTERVAL;
	num_files = 0;

	/* parse cmd line args*/
	for (i = 1; i < argc ;  i++) {
		printf(" argv[%d]='%s'\n", i, argv[i]);
		if (argv[i][0] == '-') {
			switch (argv[i][1]) {
				case 'h': { usage();          } break;

				case 'q': { exit(1); } break;

				case 'f': { 		/* read from a file */
					use_file = 1;
					sscanf(argv[++i],"%s ",input_file_name[num_files]);
					num_files++;
				} break;

				case 'i': { use_stdin=1; } break;   /* read from stdin */

				case 's': { 		/* if the sample interval is specified */
					sscanf(argv[++i],"%lf ", &sample_interval);
				} break;
				case 'T': { 		/* if we don't have a built-in timestamp in the file */
					no_timestamp_mode = 1;
				} break;


				default: {
					usage();
					exit(1);
				}
			}
		}
		else {
			strcpy( field_names[fn], argv[i]);
			show_field[fn] = 0;
			fn++;

		}
	}
	num_fields = fn;


        quit = 0;


	cfn = 0; 
	zoom_in(0,0);
	sample_time_avg = sample_interval;
	file_EOF = 0;
	current_file = 0;
	head[current_file] = 0;
	master_idx=0;
	prev[master_idx] = -1;

	while (quit == 0) {
		Do_XEvents();


		if (pause_mode == 0) {
			if (use_stdin == 1) {

				sret = scanf("%d ", &spl_val);
				sample_time_avg = sample_interval;

			}
			else if (use_file == 1) {

				if ( file_EOF == 0) {

					sret = stat(input_file_name[current_file], &stat_info);
					if (sret != 0) {
						printf("Couldn't find '%s', does it exist ?\n", input_file_name[current_file]);
						xsnore_exit();
					}

					data_file = fopen(input_file_name[current_file],"r");
					if (data_file == NULL) {
						printf("\n\n******* Couldn't open data_file ********\n\n");
						xsnore_exit();
					}

					done = 0;
					head[current_file] = master_idx;
					while (done == 0) {
						for (f=0; f<num_fields; f++) {
							wfn = f;
							sret = fscanf(data_file, "%ld", &raw_value);
							if (sret > 0) {
								if (raw_value > max_sample[wfn]) max_sample[wfn] = raw_value;
								if (raw_value < min_sample[wfn]) min_sample[wfn] = raw_value;

								data[wfn][master_idx] = raw_value;

							}
							else done=1;
						}
						master_idx++;
						if (master_idx >= MAX_DATA_SAMPLES) done=1;
					}
					current_file++;
					if (current_file > NUM_FILES) {
						printf("whoops, too many input files\n");
						xsnore_exit();
					}
				}
				actual_number_of_samples = master_idx - 1;
				window_start = 0;
				window_stop  =  actual_number_of_samples;
	
				if (debug_level > 0) printf("\n%d samples read from data_file\n\n", actual_number_of_samples);	
				if (debug_level > 0) printf("max_sample[0]=%ld  min_sample[0]=%ld \n", max_sample[0], min_sample[0]);
				fclose(data_file);
				file_EOF=1;
				sample_time_avg = sample_interval;
				pause_mode = 1;
			}

		}
		passes++;
		if (repaint_request != 0) {
			xdata_repaint();
		}
	}
}






usage() {
	printf("Usage:\n");
	printf("./snorelab <-f filename>  field1 field2 field3 fieldxxx   \n");
	printf("options are:\n");
	printf("\n");
	exit(1);
}






xsnore_exit() {

	exit(0);

}
 





xdata_repaint()  {

	if (use_dbe == 0) {
		display_data();
		show_cursor_values();
	}
	else {

		if (repaint_request != 0) {
			XdbeBeginIdiom( mydisplay );
			display_data();
			show_cursor_values();

			swap_info.swap_action = XdbeBackground;
			XdbeSwapBuffers( mydisplay, &swap_info, 1);

			XdbeEndIdiom( mydisplay );
		}
		else if (repaint_request == 2) {
/*
			XdbeBeginIdiom( mydisplay );
			swap_info.swap_action = XdbeUntouched;
			XdbeSwapBuffers( mydisplay, &swap_info, 1);

//			show_cursor_values();

			XdbeEndIdiom( mydisplay );
*/
		}
	}
	repaint_request = 0;
}








init() {
int	i, j, k;
Status  Lookup_result;
XColor  exact;
unsigned char trash_char;
int     sret;
const char *display = ":0.0";


	debug_level = DEBUG;

        mydisplay = XOpenDisplay(display);
        if (!mydisplay) {
		printf("Error, can't open display...\n");
		exit(1);
	}	
        myscreen  = DefaultScreen(mydisplay);


	Make_Window(Main_Window, 100,100, INITIAL_XUR + 10, INITIAL_YLL + 10);

	current_yll = INITIAL_YLL;
	current_xll = INITIAL_XLL;
	current_xur = INITIAL_XUR;
	current_yur = INITIAL_YUR;

	The_cmap[Main_Window] = DefaultColormap( mydisplay, myscreen );

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "seashell", &exact, &Background);
	XAllocColor(mydisplay, The_cmap[Main_Window], &Background);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "black", &exact, &Black);
	XAllocColor(mydisplay, The_cmap[Main_Window], &Black);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "white", &exact, &White);
	XAllocColor(mydisplay, The_cmap[Main_Window], &White);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "black", &exact, &channel_color[6]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[6]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "red1", &exact, &channel_color[0]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[0]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "brown", &exact, &channel_color[2]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[2]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "blue", &exact, &channel_color[3]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[3]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "purple", &exact, &channel_color[4]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[4]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "orange", &exact, &channel_color[5]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[5]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "green", &exact, &channel_color[1]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[1]);

	Lookup_result = XLookupColor(mydisplay, The_cmap[Main_Window], "violet", &exact, &channel_color[7]);
	XAllocColor(mydisplay, The_cmap[Main_Window], &channel_color[7]);

	font = XLoadFont(mydisplay, "12x24\0");
		XSetFont(mydisplay, The_gc[Main_Window], font);

	timer_interval = 99000;
	timer_struct.it_interval.tv_usec = timer_interval;
	timer_struct.it_value.tv_usec    = timer_interval;

	for (k=0; k < NUM_FILES; k++) {
		head[k] = -1;
	}

	for (k=0; k!= NUM_FIELDS; k++) {
		for (j=0; j!= MAX_DATA_SAMPLES; j++) {
			data[k][j] =  0;
			next[j] = -1;
			prev[j] = -1;
		}

		actual_number_of_samples = 0;
		y_offset[k] = 0;
		y_delta[k] = 0;

		yscale[k] = 1.0;
		min_sample[k] =  9999999999999;
		max_sample[k] = -9999999999999;

		show_field[k] = -1;
	}

	cursor_position = -1;
	window_start = 0;
	window_stop  =  100;

	mouse_is_down = 0;
	quit=0;
	passes = 0;
	scroll_mode = 1;
	pause_mode = 0;


	ctrl_pressed = 0;
	alt_pressed = 0;
	shift_pressed = 0;
	Double_Clicked = 0;

	show_grid = 1;
}








 
Make_Window(Window_ID, Window_Left, Window_Down, Window_Width, Window_Height)
        int Window_ID, Window_Left, Window_Down, Window_Width, Window_Height; {
int     majorVersion, minorVersion;
 
        /* default pixel values */
 
        The_background[Window_ID] = WhitePixel(mydisplay, myscreen);
        The_foreground[Window_ID] = BlackPixel(mydisplay, myscreen);
 
        /* Default program-specified window position and size */
        The_hint[Window_ID].x = Window_Left;
        The_hint[Window_ID].y = Window_Down;

        The_hint[Window_ID].width  = Window_Width;
        The_hint[Window_ID].height = Window_Height;
        The_hint[Window_ID].flags = PPosition | PSize;
        The_wmhint[Window_ID].flags = InputHint;
        The_wmhint[Window_ID].input = True;
 
        /* Window_ID window creation */
        The_Window[Window_ID] = XCreateSimpleWindow(mydisplay,  DefaultRootWindow(mydisplay),
                The_hint[Window_ID].x, The_hint[Window_ID].y, The_hint[Window_ID].width,
                The_hint[Window_ID].height, 5,  The_foreground[Window_ID], The_background[Window_ID]);

                                                                                                       
        XSetStandardProperties(mydisplay,  The_Window[Window_ID], text, text, None, 0, 0, &The_hint[Window_ID]);
        XSetWMHints(mydisplay, The_Window[Window_ID], &The_wmhint[Window_ID]);

        /* GC creation and initialization */
        The_gc[Window_ID] = XCreateGC(mydisplay, The_Window[Window_ID], 0,0);

        XSetBackground(mydisplay, The_gc[Window_ID], The_background[Window_ID]);
        XSetForeground(mydisplay, The_gc[Window_ID], The_foreground[Window_ID]);

        /* input event selection */                                              
        XSelectInput(mydisplay, The_Window[Window_ID], ButtonPressMask | ButtonReleaseMask | KeyPressMask | KeyReleaseMask | ExposureMask | PointerMotionMask);
 
        /* window mapping */
        XMapRaised(mydisplay, The_Window[Window_ID]);


        if (XdbeQueryExtension (mydisplay, &majorVersion, &minorVersion)) {

		use_dbe = 1;

		swap_info.swap_window = The_Window[Window_ID];
		swap_info.swap_action = XdbeBackground;
 
		Double_Buffer[Window_ID] =  XdbeAllocateBackBufferName(mydisplay, The_Window[Window_ID],  swap_info.swap_action);
		if (Double_Buffer[Window_ID] == 0) printf("Error in XdbeAllocateBackBuffer...\n");

	} else {
		if (debug_level > 0) printf("Error, no Double-buffer extensions, using single buffer...\n");
		Double_Buffer[0] =  The_Window[Window_ID];
		use_dbe = 0;
	}


}
 








Do_XEvents() {
int	ch, f;
long	i, evmask, x_shift;
KeySym  the_keysym;
XEvent	ahead;

	evmask = ButtonPressMask | ButtonReleaseMask | KeyPressMask | KeyReleaseMask | ExposureMask | PointerMotionMask;
	if (XCheckWindowEvent(mydisplay, The_Window[Main_Window], evmask, &myevent) != 0)  {
		/* read next event */
		switch( myevent.type ) {
			case Expose:	/* repaint window on expose events */
                                XGetWindowAttributes( mydisplay, The_Window[Main_Window], &(The_attribs[Main_Window]) );
				current_xll = INITIAL_XLL;
				current_yur = INITIAL_YUR;
				current_xur =  The_attribs[Main_Window].width  - current_xll -1 -LABEL_WIDTH;
				current_yll =  The_attribs[Main_Window].height - current_yur -1;

				if (myevent.xexpose.count == 0) {
					/* indicate that a re-draw is needed */
					repaint_request = 1;
				}
				break;

			case NoExpose:	
				break;

			case GraphicsExpose:	
				break;

			case MappingNotify:	/* process keyboard mapping changes */
				XRefreshKeyboardMapping( &(myevent.xmapping));
				break;

			case ButtonPress:	/* process mouse-button presses */
				mouse_x = myevent.xbutton.x;
				mouse_y = myevent.xbutton.y;
				button_type = myevent.xbutton.button;
		
				if (button_type ==4) {
					if (ctrl_pressed == 0) {
						if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
							yscale[cfn] *= 1.5;

							repaint_request = 1;
						}
					}
					else {
						mouse_index = window_start + (int)( (double)(window_stop-window_start) 
						    * (double)(mouse_x - current_xll)/(double)(current_xur-current_xll-20) );
						zoom_in(1, mouse_index);
						repaint_request = 1;
					}
				}
				if (button_type ==5) {
					if (ctrl_pressed == 0) {
						if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
							yscale[cfn] /= 1.5;
							repaint_request = 1;
						}
					}
					else	{
						mouse_index = window_start + (int)( (double)(window_stop-window_start) 
						    * (double)(mouse_x - current_xll)/(double)(current_xur-current_xll-20) );
						zoom_out(1, mouse_index);
						repaint_request = 1;
					}
				}

				do_mouse_down(mouse_x, mouse_y);

	
				MouseDTime = myevent.xbutton.time;
				if ((MouseDTime - LastMouseDown) <= DOUBLETIME) {
					Double_Clicked = 1;
					omarker_x = marker_x;
					omarker_y = marker_y;
					omarker_data = marker_data;
					omarker_time = marker_time;
					old_mouse_index = mouse_index;

					marker_x = myevent.xbutton.x;
					marker_y = myevent.xbutton.y;
					mouse_index = window_start + (int)( (double)(window_stop-window_start) 
					    * (double)(marker_x - current_xll)/(double)(current_xur-current_xll-20) );

					marker_data = data[cfn][mouse_index];
					marker_time = mouse_index * sample_time_avg;
					marker_value_delta = marker_data - omarker_data;
					if (no_timestamp_mode == 1) 
						marker_time_delta = marker_time - omarker_time;
					else 
						marker_time_delta = (int)( data[0][mouse_index] - data[0][old_mouse_index]);

					if (debug_level > 0) printf("Double Click dtime=%d  idx:%d    Delta=%f => %3.1f\n",
						       	(int)(MouseDTime - LastMouseDown), mouse_index, marker_time_delta, (60.0/marker_time_delta)  );
				}
				LastMouseDown = MouseDTime;
			
				break;
			
			case ButtonRelease:	/* process mouse-button releases */
				mouse_x = myevent.xbutton.x;
				mouse_y = myevent.xbutton.y;
				button_type = myevent.xbutton.button;
				do_mouse_up(mouse_x, mouse_y);
				break;

			case KeyPress:		/* process keyboard input */
				i = XLookupString ( &(myevent.xkey), text, 10, &the_keysym, 0);
				if (i == 0) {
					if (myevent.xkey.keycode == 0x25) ctrl_pressed = 1;
					if (myevent.xkey.keycode == 0x40) alt_pressed = 1;
					if (myevent.xkey.keycode == 0x32) shift_pressed = 1;

					if (myevent.xkey.keycode == 0x69) ctrl_pressed = 1;
					if (myevent.xkey.keycode == 0x6C) alt_pressed = 1;
					if (myevent.xkey.keycode == 0x3E) shift_pressed = 1;
				}
				if (i == 1) {
					key = text[0];
					if (key == 'q') quit = 1;
					if (key == '+') zoom_in(0,0);
					if (key == '-') zoom_out(0,0);
					if (key == 'g') show_grid ^= 1;
					if (key == 'S') scroll_mode ^= 1;
					if (key == ' ') pause_mode ^= 1;
					if (key == 'b') XdbeSwapBuffers( mydisplay, &swap_info, 1);
					if (key == 'D') debug_level ^= 1;
					if (key == 'Z') {
						if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
							yscale[cfn] *= 1.5;
							repaint_request = 1;
						}
					}

					if (key == 'z') {
						if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
							yscale[cfn] /= 1.5;
							repaint_request = 1;
						}
					}
					if (key == '.') {
						if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
							for (f=0; f!= NUM_FIELDS; f++) {
								y_offset[cfn] = 0;
								y_delta[cfn] = 0;
								yscale[cfn] = 1.0;
							}
							repaint_request = 1;
						}
					}
					if ((key >= '0')  && (key <= '9')) {
						show_field[ (key - '0') ] ^= 1;	
						cfn = key - '0';
						repaint_request = 1;
					}

				}
				else key = 0;
				break;

			case KeyRelease:		/* process keyboard release */
				i = XLookupString ( &(myevent.xkey), text, 10, &the_keysym, 0);
				if (i == 0) {
					if (myevent.xkey.keycode == 0x25) ctrl_pressed = 0;
					if (myevent.xkey.keycode == 0x40) alt_pressed = 0;
					if (myevent.xkey.keycode == 0x32) shift_pressed = 0;

					if (myevent.xkey.keycode == 0x69) ctrl_pressed = 0;
					if (myevent.xkey.keycode == 0x6C) alt_pressed = 0;
					if (myevent.xkey.keycode == 0x3E) shift_pressed = 0;
				}
				break;
			case MotionNotify:
				while (XEventsQueued(myevent.xmotion.display, QueuedAfterReading) > 0)  {
					XPeekEvent(myevent.xmotion.display, &ahead);
					if (ahead.type != MotionNotify) break;
					if (ahead.xmotion.window != myevent.xmotion.window) break;
					XNextEvent(myevent.xmotion.display, &myevent);
				}

				mouse_x = myevent.xmotion.x;
				mouse_y = myevent.xmotion.y;

				if (mouse_is_down == 1) {
					do_mouse_moved();
					repaint_request = 1;
				}
				else	{
//					show_cursor_values();
					repaint_request = 2;
				}

				break;
		}

//		if (debug_level > 0) printf("yscale[0]= %f,  y_offset[0]=%d  y_delta[0]=%d\t", yscale[0], y_offset[0], y_delta[0]);
//		if (debug_level > 0) printf("mouse_index = %d  window_start=%d,  window_stop=%d\n", mouse_index, window_start, window_stop);
	}
}








which_fn(x, y) int x,y; {
int	mouse_index, f, found, s1, y1;	
int	pix_dist;

	mouse_index = window_start + (int)( (double)(window_stop-window_start) 
		    * (double)(mouse_x - current_xll)/(double)(current_xur-current_xll-20) );

	found = -1;
	f=0;
	while ((found < 0) && (f < num_fields)) {

		if (show_field[f] == 1) {

			s1 = (int)(yscale[f] * ( (double)(current_yll - 24) * ((double)data[f][mouse_index] - (double)min_sample[f])/((double)max_sample[f] - (double)min_sample[f])));
			y1 = (current_yll - 2) - s1 + y_offset[f] - y_delta[f];
			pix_dist =   abs(y - y1);

			if (pix_dist < MAX_PIX_DIST) {
				found=f;
			}
		}
		f++;
	}
	if (found >= 0) return(found);
	else return(-1);
}






do_mouse_down(mouse_x, mouse_y) int mouse_x, mouse_y; {

	mouse_is_down = 1;
	mouse_down_x = mouse_x;
	mouse_down_y = mouse_y;

	if ((button_type != 4) && (button_type != 5)) {
		mf = which_fn( mouse_x, mouse_y);
		if (mf >=0 ) {
			cfn = mf;
		}
		else cfn = 0;
	}
}





do_mouse_moved() {
int	i, f;

	m_x_delta = mouse_down_x - mouse_x;
	m_y_delta = mouse_down_y - mouse_y;
	if (m_x_delta != 0) xdelta = (int)( (double)(window_stop-window_start) * ((double)m_x_delta / (double)(current_xur-current_xll-20) ) +0.5);

	if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
		y_delta[cfn] = m_y_delta;
	}

	if ((xdelta != old_xdelta) || (m_y_delta != old_m_y_delta)) repaint_request = 1;
}





do_mouse_up(mouse_x, mouse_y) int mouse_x, mouse_y; {
int	i, state_y, f;

	mouse_is_down = 0;
	mouse_up_x = mouse_x;
	mouse_up_y = mouse_y;

	if (mouse_x < current_xur) {	// if inside ploting region
		m_x_delta = mouse_down_x - mouse_x;
		xdelta = (int)( (double)(window_stop-window_start) 
			* ((double)m_x_delta / (double)(current_xur-current_xll-20) ) +0.5);

		window_start += xdelta;
		window_stop  += xdelta;
		m_x_delta = 0;

		m_y_delta = mouse_down_y - mouse_up_y;
		if ( (mouse_y > current_yur) && (mouse_y < current_yll) ) {
			y_offset[cfn] -= m_y_delta;
			y_delta[cfn] = 0;
			m_y_delta = 0;
		}
	}
	else {				// if inside field label region
		printf("Inside X  (%d, %d)  nf=%d\n", mouse_x, mouse_y,  num_fields);
		if ( (mouse_y > current_yur) && (mouse_y < (current_yur + num_fields*LABEL_STRIDE + 5))) {
			f= (mouse_y - current_yur -10 ) / LABEL_STRIDE ;
			show_field[ f ] ^= 1;
			cfn = f;
		}
	}

	repaint_request = 1;
}








scroll_traces( delta ) int delta; {

	xdelta = (int)( (double)(window_stop-window_start) * ((double)delta / (double)(current_xur-current_xll-20) ) +0.5);
	window_start += xdelta;
	window_stop  += xdelta;
}




zoom_in( mode, mouse_index ) int mode, mouse_index; {
int	win_span, win_center;

	if (mode == 0) {
		win_center = (window_stop + window_start)/2;
		if (window_start != window_stop) 
			win_span   = (window_stop - window_start);
		else 	win_span   = (window_stop - window_start) + 1;

		window_start = win_center - (win_span/2)/2;
		window_stop  = win_center + (win_span/2)/2;
	}
	else   {
		window_start = mouse_index - ((mouse_index - window_start)/2);
		window_stop  = mouse_index + ((window_stop - mouse_index)/2);
	}

	repaint_request = 1;
}


zoom_out(mode, mouse_index ) int mode, mouse_index; {
int	win_span, win_center;

	if (mode == 0) {
		win_center = (window_stop + window_start)/2;
		if (window_start != window_stop) 
			win_span   = (window_stop - window_start);
		else 	win_span   = (window_stop - window_start) + 1;

		window_start = win_center - (win_span*2)/2;
		window_stop  = win_center + (win_span*2)/2;
		if (window_start == window_stop) {
			window_start--;
			window_stop++;
		}
	}
	else    {
		window_start = mouse_index - ((mouse_index - window_start)*2);
		window_stop  = mouse_index + ((window_stop - mouse_index)*2);
		if (window_start == window_stop) {
			window_start--;
			window_stop++;
		}
		if (window_start > window_stop) {
			window_start = window_stop - 1;
			window_stop++;
		}
//		printf("start=%d,  stop=%d\n", window_start, window_stop );
	}

	repaint_request = 1;
}







show_cursor_values() {
int	mouse_index, i, x,y;
double	current_val, voltage_val;
int	hours, min, sec, msec;

	if ( (mouse_x > current_xll) && (mouse_x < current_xur) ) {

		mouse_index = window_start + (int)( (double)(window_stop-window_start) 
			    * (double)(mouse_x - current_xll)/(double)(current_xur-current_xll-20) );


		if ( (mouse_y > current_yur) && (mouse_y < current_yll ) ) {
			if ((mouse_index >= 0) && (mouse_index < actual_number_of_samples)) {

				XSetForeground(mydisplay, The_gc[Main_Window], channel_color[cfn%NUM_COLORS].pixel);

				if (no_timestamp_mode == 1) {

					hours = (int)(        (mouse_index * sample_time_avg)/60.0/60.0);
					min   = (int)(      (((mouse_index * sample_time_avg)/60.0/60.0) - (double)hours)*60.0);
					sec   = (int)(    (((((mouse_index * sample_time_avg)/60.0/60.0) - (double)hours)*60.0) - (double)min)*60.0);
					msec  = (int)(  (((((((mouse_index * sample_time_avg)/60.0/60.0) - (double)hours)*60.0) - (double)min)*60.0) - (double)sec)*1000.0);
					sprintf(text,"%s[%02d:%02d:%02d.%03d] %s = %9ld", field_names[cfn], hours, min, sec, msec, field_names[cfn], data[cfn][mouse_index] );

				} else {

					convert_time( data[0][mouse_index]/1000 );
					sprintf(text,"%s.%03ld %s = %9ld ", time_res, (data[0][mouse_index]%1000), field_names[cfn], data[cfn][mouse_index]);

				}
				XDrawImageString( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],
					(current_xll + 20), current_yur - 5, text, strlen(text));

				XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);

			}
			mouse_data_index = mouse_index;
		}
	}

	XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);
}



convert_time( timestamp ) time_t timestamp; {
static const char default_format[] = "%a %b %d %Y %H:%M:%S";
const char *format = default_format;
time_t  t;
struct tm lt;


	t = timestamp;
	(void) localtime_r(&t, &lt);

	if (strftime(time_res, sizeof(time_res), format, &lt) == 0) {
		(void) fprintf(stderr,  "strftime(3): cannot format supplied "
					"date/time into buffer of size %lu "
					"using: '%s'\n",
					sizeof(time_res), format);
		return 1;
	}

	if (debug_level > 1) (void) printf("%ld     %lu -> '%s'\n", timestamp, (long unsigned)t, time_res);
	return 0;
	
}







display_data() {
int	i, j, x1,y1, x2, y2, ch, field;
int	x1p, y1p, x2p, y2p, y1t, y2t;
int	xpos1, xpos2, xstep, num_fields_to_show;
unsigned int s1, s2;
double	rand_num, display_fraction;

	xdelta = (int)( (double)(window_stop-window_start) * ((double)m_x_delta / (double)(current_xur-current_xll-20) ) +0.5);

	display_fraction = 1.0 - (1.1/((double)(window_stop-window_start)/(double)(current_xur-current_xll)));


	if (mouse_is_down == 1) {
		if ( ((double)(window_stop-window_start)/(double)(current_xur-current_xll)) > 10.0) xstep = (int)(0.1 * (double)(window_stop-window_start)/(double)(current_xur-current_xll));
		else xstep = 1;
	}
	else xstep = 1;


	XSetForeground(mydisplay, The_gc[Main_Window], Background.pixel);

	XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);
        if (use_dbe == 0)       XClearWindow( mydisplay, Double_Buffer[Main_Window]);

	XDrawLine( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],  current_xll, current_yur, current_xll, current_yll);
	XDrawLine( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],  current_xur, current_yur, current_xur, current_yll);
	XDrawLine( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],  current_xll, current_yll, current_xur, current_yll);
	XDrawLine( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],  current_xll, current_yur, current_xur, current_yur);


	for (field=0; field < NUM_FIELDS; field++) {
		XSetForeground(mydisplay, The_gc[Main_Window], channel_color[field%NUM_COLORS].pixel);
		sprintf(text,"%s", field_names[field]);
		XDrawImageString( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],
							(current_xur + 25), current_yur + 40 + (field * LABEL_STRIDE), text, strlen(text));

		if (show_field[field] == 1) {	
			XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);
			XFillRectangle( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window], 
							(current_xur + 5), current_yur + 25 + (field * LABEL_STRIDE),  10, 10);
		}
		else if (show_field[field] == 0) {	
			XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);
			XDrawRectangle( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window], 
							(current_xur + 5), current_yur + 25 + (field * LABEL_STRIDE),  10, 10);
		}
	


		if (show_field[field] == 1) {	
			font = XLoadFont(mydisplay, "12x24\0");
	                        XSetFont(mydisplay, The_gc[Main_Window], font);
	
			XSetForeground(mydisplay, The_gc[Main_Window], channel_color[0].pixel);
			sprintf(text,"TSFR 1             Time Delta = %7.3f Sec   %4.1f / min", (double)marker_time_delta/1000.0, 60.0/marker_time_delta);
			XDrawImageString( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window],
							(current_xll + 20), current_yll + 25, text, strlen(text));
	
			for (i=(window_start + xdelta); i < (window_stop + xdelta -1); i+=xstep) {
//printf("xstep=%d  i=%d  field=%d  wstart=%d  wstop=%d   xdelta=%d   corr_span=%d\n", xstep, i, field, window_start, window_stop, xdelta, corr_span);	
				if ((i > 1) && (i < actual_number_of_samples)) {
					s1 = (int)(yscale[field] * ( (double)(current_yll - 24) * ((double)data[field][i    ] - (double)min_sample[field])/((double)max_sample[field] - (double)min_sample[field])));
					s2 = (int)(yscale[field] * ( (double)(current_yll - 24) * ((double)data[field][i + 1] - (double)min_sample[field])/((double)max_sample[field] - (double)min_sample[field])));

				}
				else {
					s1 = (current_yll - 20);
					s2 = (current_yll - 20);
				}
	
				xpos1 = (int)((double)(i-window_start-xdelta   )*(double)(current_xur-current_xll-20)/(double)(window_stop-window_start) );
				xpos2 = (int)((double)(i-window_start-xdelta +1)*(double)(current_xur-current_xll-20)/(double)(window_stop-window_start) );
	
				x1 = (current_xll + 0) + xpos1;
				y1 = (current_yll - 2) - s1 + y_offset[field] - y_delta[field];
				if (y1 < current_yur) y1 = current_yur;
				if (y1 > current_yll) y1 = current_yll;
	
				x2 = (current_xll + 0) + xpos2;
				y2 = (current_yll - 2) - s2 + y_offset[field] - y_delta[field];
				if (y2 < current_yur) y2 = current_yur;
				if (y2 > current_yll) y2 = current_yll;
	
				if ((i >= 0) && (i < (actual_number_of_samples -1))) {
					XSetForeground(mydisplay, The_gc[Main_Window], channel_color[field%NUM_COLORS].pixel);
					XDrawLine( mydisplay, Double_Buffer[Main_Window], The_gc[Main_Window], x1, y1, x2, y2);
				}
	
			}
			XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);
		}
	}


	old_xdelta = xdelta;
	old_m_y_delta = m_y_delta;

	XSetForeground(mydisplay, The_gc[Main_Window], Black.pixel);

}













